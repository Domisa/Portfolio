import random
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def convertTime(unitNum, intervals, pops):

    chromCollect = []

    for i in range(pops):

        chromosome = []
        for i in range(unitNum):
            strand = []
            if intervals[i] == 1:
                strand = [[1,0,0,0], [0,1,0,0], [0,0,1,0], [0,0,0,1]]

            elif intervals[i] ==2:
                strand = [[1,1,0,0], [0,1,1,0], [0,0,1,1]]

            elif intervals[i] == 3:
                strand = [[1,1,1,0], [0,1,1,1]]

            else:
                strand = [[1,1,1,1]]
            
        
            selection = random.randint(0, len(strand)-1)
            chromosome.append(strand[selection])
        
        chromCollect.append(chromosome)
    return chromCollect
        
def evaluation(chromsPop, max, cross, mut, power):

    # ChromsPop is all the chromosomes in the population array
    bestList = []
    fullList = []

    # This is for each different chromosome as an index
    for schedule in range(len(chromsPop)):

        # I know technically this is divided into 4 intervals of an unknown length
        # This is just easier for me to read.
        
        spring = 0
        summer = 0
        autumn = 0
        winter = 0

        # This is for each unit in the chromosome
        for unit in range(len(chromsPop[schedule])):

            # This collects the total power from each unit in each interval
            if chromsPop[schedule][unit][0] == 1:
                spring+=power[unit]
            if chromsPop[schedule][unit][1] == 1:
                summer+=power[unit]
            if chromsPop[schedule][unit][2] == 1:
                autumn+=power[unit]
            if chromsPop[schedule][unit][3] == 1:
                winter+=power[unit]

        # This finds the net power for each interval

        bestCheck = []

        spring = max[0]-spring
        summer = max[1]-summer
        autumn = max[2]-autumn
        winter = max[3]-winter

        bestCheck.append(spring)
        bestCheck.append(summer)    
        bestCheck.append(autumn)
        bestCheck.append(winter)

        # This is just the best value from that chromosome, not the population
        # This will be used to calculate the average and find the best later
        bestList.append(min(bestCheck))
        fullList.append(bestCheck)

    average = sum(bestList)
    bestest = min(bestList)

    return average, bestest, fullList, bestList


def crossover(chromPop, population, probability, bestList, fullList):
    test = random.uniform(0, 1)

    if test == test:
        # print(bestList)
        #This is just to remove negative values and prevent 0
        if min(bestList) <= 0:
            loser = min(bestList)*(-1)
            # print(loser)
            for i in range(len(bestList)):
                bestList[i]=bestList[i]+loser+0.01

            # print(bestList)
        selectAmount = random.randint(1, len(chromPop[0])-1)
        spot1,spot2 = rouletteWheel(bestList)

        # print(spot1)
        # print(spot2)
        
        # print(chromPop[spot1])

        temp = chromPop[spot1][selectAmount:]
        chromPop[spot1][selectAmount:] = chromPop[spot2][selectAmount:]
        chromPop[spot2][selectAmount:] = temp
        
        # print(chromPop[spot1])
        return chromPop, bestList



    return chromPop, bestList

def mutate(chromPop, unitNum, probability, bestList, fullList):
    
    test = random.uniform(0, 1)

    if test <= test:
        chromPick = random.randint(0, len(chromPop)-1)
        popPick = random.randint(0, unitNum-1)
        seasonPick = random.randint(0, 3)

        #print(chromPop[chromPick][popPick][seasonPick])

        if chromPop[chromPick][popPick][seasonPick] == 0:
            chromPop[chromPick][popPick][seasonPick] = 1
        else:
            chromPop[chromPick][popPick][seasonPick] = 0

    return chromPop

def rouletteWheel(bestList):

    summed = sum(bestList)
    #print(summed)
    #print(bestList)
    weighted = []
    for i in bestList:
        #print(i)
        weighted.append((1-i/summed))
        #print(weighted)
    #print(weighted)
    spot1 = random.choices(bestList, weights=weighted)
    spot2 = random.choices(bestList, weights=weighted)

    while spot1==spot2:
        spot1 = random.choices(bestList, weighted)
    
    spot1 = bestList.index(spot1[0])
    spot2 = bestList.index(spot2[0])

    return spot1, spot2



#This is the initial setup for the unit data and can be edited as needed.
def main():
    #Number of units, can be edited
    units = 7

    #Number of intervals needed for maintenance for different unit in order. If units is increased, this should too.
    #I could have the user input it in manually when executed, but that is annoying to do for each run.
    #The selected chosen numbers directly reflects the problems in the slides
    numIntervals =[2,2,1,1,1,1,1]

    #The maximum power of each interval
    #firstMax, secondMax, thirdMax, fourthMax = 80, 90, 65, 70

    Maxi = [80, 90, 65, 70]
    #The power of each unit. This should be changed as needed.
    power = [20, 15, 35, 40, 15, 15, 10]
    generations = 20
    population = 20
    crossProb = .7
    mutProb = .001
    
    chromosomes = convertTime(units, numIntervals, population)

    # print(chromosomes)
    # print(len(chromosomes))
    averageList = []
    bestest = []
    for i in range(generations):

        average, best, fullList, bestList=evaluation(chromosomes, Maxi, crossProb, mutProb, power)
        # print(average)s
        # print(best)
        # print(fullList)
        # print(bestList)
        averageList.append(average)
        bestest.append(best)
        chromosomes, bestList=crossover(chromosomes, population, crossProb, bestList, fullList)
        chromosomes = mutate(chromosomes, units, mutProb, bestList, fullList) 
        # print(average)
        # print(best)
        # print(fullList)
        # print(bestList)
        # print(chromosomes)




    sns.lineplot(x=range(generations), y=averageList)
    sns.lineplot(x=range(generations), y=bestest)
    plt.title(f'N={generations}, p_c={crossProb}, p_m={mutProb}')
    plt.xlabel("Generations")
    plt.ylabel("Fitness")
    plt.show()

main()